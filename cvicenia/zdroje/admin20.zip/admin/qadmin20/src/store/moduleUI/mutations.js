export const updateDrawerState = (state, opened) => {
  state.layout.drawerState = opened
}

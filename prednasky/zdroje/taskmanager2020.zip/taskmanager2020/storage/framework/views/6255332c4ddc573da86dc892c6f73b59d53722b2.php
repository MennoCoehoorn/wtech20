<!doctype html>
<html lang="sk">
<head>
    <?php echo $__env->make('layout.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('layout.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
    <main role="main" class="container">
  
        <div class="taskmanager-template">
            <div class="row">
                <div class="col-sm-12">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>

    </main>
  
    <!-- Bootstrap core JavaScript -->
    <?php echo $__env->make('layout.partials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</body>
</html><?php /**PATH C:\wamp\www\taskmanager2020\resources\views/layout/app.blade.php ENDPATH**/ ?>